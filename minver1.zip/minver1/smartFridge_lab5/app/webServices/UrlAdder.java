package com.example.smartfridge_lab5.webServices;

interface UrlAdder {
}
