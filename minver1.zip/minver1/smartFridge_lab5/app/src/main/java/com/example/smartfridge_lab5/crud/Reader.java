package com.example.smartfridge_lab5.crud;

import android.content.Context;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.smartfridge_lab5.ListAdapter;
import com.example.smartfridge_lab5.adapter.*;
import com.example.smartfridge_lab5.contractOfCRUD.JsonConverter;
import com.example.smartfridge_lab5.contractOfCRUD.ViewSetuper;
import com.example.smartfridge_lab5.data.Items;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Reader implements JsonConverter, ViewSetuper {
    private String link;
    private RequestQueue requestQueue;
    private String id;
    public ListAdapter listAdapter;
    private ArrayList<Items> listOfItems;

    public Reader(String link) {
        this.link = link;
    }

    protected Reader(String link, String id) {
        this.link = link;
    }

    public RequestQueue readJson(Context context, ListView listView) {


        StringRequest stringRequest = new StringRequest(Request.Method.GET, this.link,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            parseJson(response.toString());
                            setupListview(context, getListOfItems(), listView);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        error.getStackTrace();
                    }
                });
        // request queue
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);
        return  requestQueue;
    }

@Override
    public ArrayList<Items> parseJson(String jsonString) {
        Gson gson = new Gson();

        //Tell the type we want to convert to.
        Type collectionType = new TypeToken<ArrayList<Items>>(){}.getType();

        //Do the parsing
        listOfItems = gson.fromJson(jsonString, collectionType);

        return listOfItems;
    }

    private void setListOfItems(ArrayList<Items> listOfItems) {
        this.listOfItems = listOfItems;
    }

    public ArrayList<Items> getListOfItems() {
        return this.listOfItems;
    }

    @Override
    public void setupListview(Context context, ArrayList<Items> list, ListView listView) {
        listAdapter = new ListAdapter(context, list);
        listView.setAdapter(listAdapter);
    }
}

