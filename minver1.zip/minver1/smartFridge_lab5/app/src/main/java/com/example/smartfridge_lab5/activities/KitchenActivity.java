package com.example.smartfridge_lab5.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.smartfridge_lab5.data.Items;
import com.example.smartfridge_lab5.R;
import com.example.smartfridge_lab5.crud.Reader;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;


public class KitchenActivity extends AppCompatActivity {
    private static final String URL = "https://kitchen-help.herokuapp.com/kitchen";
    private ListView listView;
ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kitchen_activity);
        listView = findViewById(R.id.lv);

      setupListview();
    }


    private void setupListview() {
        Reader reader = new Reader(URL);
      reader.readJson(this, listView);

    }


}
  /*holder.b.setTag(R.id.pos, position);
        holder.b.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final String deleteReqUrl = "https://kitchen-help.herokuapp.com/kitchen/" + dataModelArrayList.get(position).get_id();
            int index = IntStream.range(0, dataModelArrayList.size())
                    .filter(i -> dataModelArrayList.get(position).get_id().equals(dataModelArrayList.get(i).get_id()))
                    .findFirst().orElse(-1);
            System.out.println(index);
            dataModelArrayList.remove(index);
            notifyDataSetChanged();

            RequestQueue requestQueue = Volley.newRequestQueue(context);


            StringRequest mStringRequest = new StringRequest(Request.Method.DELETE, deleteReqUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {


                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("Error.Response", "response");
                        }
                    }
            );
            requestQueue.add(mStringRequest);

        }

    });
    holder = (ViewHolder) convertView.getTag(); */






