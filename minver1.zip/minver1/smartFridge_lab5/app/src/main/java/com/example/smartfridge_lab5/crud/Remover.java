package com.example.smartfridge_lab5.crud;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Remover {


    Remover(Context context, String deleteReqUrl) {

        RequestQueue requestQueue = Volley.newRequestQueue(context);


        StringRequest mStringRequest = new StringRequest(Request.Method.DELETE, deleteReqUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", "response");
                    }
                }
        );
        requestQueue.add(mStringRequest);

    }

}
