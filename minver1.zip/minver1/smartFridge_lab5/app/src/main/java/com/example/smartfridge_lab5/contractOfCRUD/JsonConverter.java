package com.example.smartfridge_lab5.contractOfCRUD;

import com.example.smartfridge_lab5.data.Items;
import com.google.gson.Gson;

import java.util.ArrayList;

public interface JsonConverter {

  ArrayList<Items> parseJson(String response);
}
