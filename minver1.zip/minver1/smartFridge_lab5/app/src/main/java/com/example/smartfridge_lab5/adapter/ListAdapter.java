package com.example.smartfridge_lab5;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.smartfridge_lab5.data.Items;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.stream.IntStream;

public class ListAdapter extends BaseAdapter {
    public ViewHolder holder;

    private Context context;
    private ArrayList<Items> dataModelArrayList;

    public ListAdapter(Context context, ArrayList<Items> dataModelArrayList) {

        this.context = context;
        this.dataModelArrayList = dataModelArrayList;
    }

    @Override
    public int getViewTypeCount() {
        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    @Override
    public int getCount() {
        return dataModelArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return dataModelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        System.out.println(position);

        holder = new ViewHolder();
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.custom_layout, null, true);


        holder._id = (TextView) convertView.findViewById(R.id._id);
        holder.name = (TextView) convertView.findViewById(R.id.name);
        holder.image = (ImageView) convertView.findViewById(R.id.pic);
        holder.b = (Button) convertView.findViewById(R.id.btnDelete);


        holder.name.setText(dataModelArrayList.get(position).getName());
        ImageView image =  (ImageView) convertView.findViewById(R.id.pic);
        loadPhotoFromInternet(dataModelArrayList.get(position).getPicture() ,image);
        holder.b.setTag(R.id.pos, position);

        holder.b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String deleteReqUrl = "https://kitchen-help.herokuapp.com/kitchen/" + dataModelArrayList.get(position).get_id();
                int index = IntStream.range(0, dataModelArrayList.size())
                        .filter(i -> dataModelArrayList.get(position).get_id().equals(dataModelArrayList.get(i).get_id()))
                        .findFirst().orElse(-1);
                System.out.println(index);
                dataModelArrayList.remove(index);
                notifyDataSetChanged();

                RequestQueue requestQueue = Volley.newRequestQueue(context);


                StringRequest mStringRequest = new StringRequest(Request.Method.DELETE, deleteReqUrl,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {


                            }

                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.d("Error.Response", "response");
                            }
                        }
                );
                requestQueue.add(mStringRequest);

            }

        });
        holder = (ViewHolder) convertView.getTag();
        return convertView;
    }


    private class ViewHolder {

        protected TextView expire_date, _id, name, short_name, link, ean_number, created_date, __v;
        ImageView image;
        Button b;
    }


    private void loadPhotoFromInternet(String url, ImageView imageEmoji) {
        if (URLUtil.isValidUrl(url)) {
            Picasso.get()
                    .load(url)
                    .into(imageEmoji);
        } else {
            Picasso.get()
                    .load(new File(url))
                    .into(imageEmoji);
        }
    }

}
