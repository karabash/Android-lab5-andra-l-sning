package com.example.smartfridge_lab5.data;

public class Items implements Comparable<Items>{
    private  String expire_date;
    private String _id;
    private String name;
    private String shortName;
    private String link;

    private  String picture;
    private  String ean_number;
    private  String created_date;
    private String __v;

   public Items(String expire_date, String _id, String name, String shortName, String link, String picture, String ean_number, String created_date, String __v) {
        this.expire_date =expire_date;
        this._id = _id;
        this.name = name;
        this.shortName = shortName;
        this.link = link;
        this.picture =picture;
        this.ean_number =ean_number;
        this.created_date =created_date;
        this.__v =__v;


    }

    public Items( String name, String picture, String _id) {
        this.name = name;
        this.picture =picture;
        this._id = _id;
    }

    public boolean equals(Items items){
       return items._id.hashCode() == (this._id.hashCode());
    }

    public int hashCode(){
        return this.get_id().hashCode();
    }

    @Override
    public int compareTo(Items s) {
        return this.get_id().compareTo(s.get_id());
    }

// Getter Methods
    public String getExpire_date() {
        return expire_date;
    }

    public String get_id() {
        return _id;
    }

    public String getName() {
        return name;
    }

    public String getPicture() {
        return picture;
    }

    public String getEan_number() {
        return ean_number;
    }

    public String getCreated_date() {
        return created_date;
    }

    public String get__v() {
        return __v;
    }

// Setter Methods

    public void setExpire_date(String expire_date) {
        this.expire_date = expire_date;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public void setEan_number(String ean_number) {
        this.ean_number = ean_number;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public void set__v(String __v) {
        this.__v = __v;
    }

    public String toString(){
        return this.expire_date   +" "+  _id+ " "+ name+  " "+picture+ " " +ean_number+ " "+created_date+" "+__v;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}