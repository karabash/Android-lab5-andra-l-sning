package com.example.smartfridge_lab5.tastelineLoader;

import android.webkit.WebView;

@FunctionalInterface
public interface IWebPAgeLoader {

    public abstract void loader(String url, WebView webView);

    }
