package com.example.smartfridge_lab5.contractOfCRUD;

import android.content.Context;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.example.smartfridge_lab5.data.Items;

import java.util.ArrayList;
import java.util.List;

public interface ViewSetuper {
    public abstract void setupListview(Context context, ArrayList<Items> list, ListView listView);


    }
