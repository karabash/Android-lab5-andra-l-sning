package com.example.smartfridge_lab5.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.smartfridge_lab5.R;
import com.example.smartfridge_lab5.tastelineLoader.IWebPAgeLoader;

public class WebPageLoaderActivity extends AppCompatActivity implements IWebPAgeLoader {
    private WebView webView;
    private static final String LOG_TAG = WebPageLoaderActivity.class.getSimpleName();
private static final String URL  = "https://www.tasteline.com/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_page_loader); loader(URL, webView);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

     @Override
    public void loader(String url, WebView webView) {
        webView = (WebView) findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(url);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }
}
