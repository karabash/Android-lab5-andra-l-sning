package com.example.smartfridge_lab5.adapter;

import com.example.smartfridge_lab5.data.Items;

import java.util.List;

interface ItemindexFinder {
    public int removeItemIndex(List<Items> dataModelArrayList, int position);

    }
